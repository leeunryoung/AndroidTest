INSERT INTO "C##HIMEDIA".MEMBER2 (ID,PWD,NAME,AGE,GENDER,ADDRESS,GURUK_YEAR,SPECIALTY) VALUES
	 ('veus','100111','kim','29','MAN','bucheon','3','forehand & rally'),
	 ('audus','0000','lee','32','WOMAN','Seoul','9','backhand & power'),
	 ('gaus','1234','bak','39','WOMAN','songpagu','4','forehand & serve'),
	 ('ciusig','4567','kim','28','MAN','busan','1','serve & volley'),
	 ('gallrug','78910','hong','32','MAN','busan','5','receive'),
	 ('impara','91112','jong','31','WOMAN','Seoul','9','service return');
