INSERT INTO "C##MUSTHAVE".DOG (DOGNO,KINDCODE,NAME,COLOR) VALUES
	 (1,'a001','밀키','white'),
	 (2,'b001','루디','gray'),
	 (3,'a001','초코','brown'),
	 (4,'c001','차돌','yellow'),
	 (5,'b001','해피','black');
