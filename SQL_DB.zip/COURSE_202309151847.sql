INSERT INTO "C##HIMEDIA".COURSE (COURSE_ID,TITLE,CREDIT) VALUES
	 ('C101','computer',3),
	 ('C102','datastructure',3),
	 ('C103','database',4),
	 ('C301','OS',3),
	 ('C302','compstructure',3),
	 ('C303','mathmatics',4),
	 ('C304','objectprog',4),
	 ('C501','AI',3),
	 ('C502','algorithm',2);
