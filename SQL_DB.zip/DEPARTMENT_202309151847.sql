INSERT INTO "C##HIMEDIA".DEPARTMENT (DEPT_ID,DEPT_NAME,OFFICE) VALUES
	 ('920','컴퓨터공학과','201호'),
	 ('923','산업공학과','207호'),
	 ('925','전자공학과','308호');
